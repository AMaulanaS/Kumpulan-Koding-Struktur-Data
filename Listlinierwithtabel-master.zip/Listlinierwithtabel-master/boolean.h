#ifndef BOOLEAN_H_INCLUDED
#define BOOLEAN_H_INCLUDED

#define true 1
#define false 0
#define boolean unsigned char

#endif // BOOLEAN_H_INCLUDED
