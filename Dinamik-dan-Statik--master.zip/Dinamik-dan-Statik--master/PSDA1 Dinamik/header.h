/*Kamal Aziz Adinata / A11.2013.07615*/
#ifndef STACKH_H_INCLUDED
#define STACKH_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

#define true 1
#define false 0
#define boolean unsigned char


typedef int infotype;
typedef int address;

typedef struct{
    infotype *T;
    address TOP;
    int Size;
}Stack;

void Createempty(Stack *S,int Sz);
void Destruct(Stack *S);
void Push(Stack *S,infotype x);
void Pop(Stack *S,infotype *x);
boolean IsEmpty(Stack S);
boolean IsFull(Stack S);
#endif // STACKH_H_INCLUDED
