/*Kamal Aziz Adinata / A11.2013.07615*/
#include  "header.h"

int pjg, n, i;
Stack S;
char pil;
infotype X;

int main()
{
    printf ("\t\t+++++++++++++++++++++++++\n");
    printf ("\t\t+   ADT STACK DINAMIK   +\n");
    printf ("\t\t+++++++++++++++++++++++++\n");

    printf("Berapa panjang STACK ?: "); scanf("%d",&pjg);

        printf("\n++MENGOSONGKAN STACK++\n");
      Createempty(&S,pjg);
        printf("\tCek STACK kosong : %s\n",IsEmpty(S)?"Ya":"Tidak");
        printf("\tCek STACK penuh  : %s\n",IsFull(S)?"Ya":"Tidak");

    printf("\n++PENGINPUTAN PUSH++\n");
    printf("Berapa kali anda akan Push ?: "); scanf("%d",&n);
    printf("Masukan InfoTop!\n\n");

    for(i=0;i<n;i++)
    {
        if(i==pjg) {
            printf ("========================\n");
            printf("Maaf STACK telah penuh");
            printf ("\n========================\n\n");
            i=n;
        } else{
            printf("\tTop[%d] ,--> InfoTop : ",S.TOP+1);
                scanf("%d",&X);
            Push(&S,X);
        }
    }

    printf ("\n++TAMPILAN STACK++");
    printf ("\n\tTop   |  InfoTop \n\t----------------\n");
    i=(S).TOP;
    while (i>=1)
    {
        printf ("\t[%d]   |   [%d] \n", i, (S).T[i]);
        i--;
    }

        printf ("\n++PERINTAH MENGAMBIL STACK++\n");
        printf ("Coba Pop-kan! [y/t]");
            pil=getche();
                if (pil=='y' || pil=='Y'){
                    goto atas;
                }
                else
                {
                    goto bawah;
                }
        atas:
            printf ("\n\tTop   |  InfoTop \n\t----------------\n");
            Pop (&S, &X);
            i=(S).TOP;
            while (i>=1)
            {
                printf ("\t[%d]   |   [%d] \n", i, (S).T[i]);
                i--;
            }
            printf ("\nIngin POP lagi ? [y/t]");
                pil=getche();
                if (pil=='y' || pil=='Y'){
                    if (((S).TOP) < 1){
                        printf ("\nStack Kosong :(, tidak bisa Pop.");
                        goto bawah;
                    }else{
                        goto atas;
                    }
                }else{
                    goto bawah;
                }
    bawah:
    printf("\n\nCek STACK kosong ?: %s\n",IsEmpty(S)?"Ya":"Tidak");
    printf("Cek STACK penuh  ?: %s\n\n",IsFull(S)?"Ya":"Tidak");

    printf("\n++DESTRUK STACK++\n");
    Destruct(&S);
    printf("STACK berhasil dihancurkan!\n");

    return 0;
}
