/*Kamal Aziz Adinata / A11.2013.07615*/
#include "header.h"

void Createempty(Stack *S,int Sz)
{
    (*S).T=(infotype *)malloc((Sz+1) * sizeof(infotype));
    (*S).TOP=0;
    (*S).Size=Sz;
}
void Destruct(Stack *S)
{
    free((*S).T);
    (*S).TOP=0;
    (*S).Size=0;
}
void Push(Stack *S,infotype x)
{
    (*S).TOP++;
    (*S).T[(*S).TOP]=x;

}
void Pop(Stack *S,infotype *x)
{
     *x=(*S).T[(*S).TOP];
    (*S).TOP--;
}

boolean IsEmpty(Stack S)
{
    if(S.TOP==0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
boolean IsFull(Stack S)
{
    if(S.TOP==S.Size) return true;
    else return false;
}
