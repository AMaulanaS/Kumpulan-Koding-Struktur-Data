#include <stdio.h>
#include <stdlib.h>
#include "header.h"

Stack S;
infotype i,n,y;
char pil;

int main()
{
    printf ("\t\t++++++++++++++++++++++++\n");
    printf ("\t\t+   ADT STACK STATIK   +\n");
    printf ("\t\t++++++++++++++++++++++++\n");

    CreateEmpty(&S);
    printf ("Mengosongkan Stack . . . .\n");
    printf("\tCek STACK kosong ? : %s\n", IsEmpty(S)?"Ya":"Tidak");
    printf("\tCek STACK penuh  ? : %s\n\n", IsFull(S)?"Ya":"Tidak");

    /*Input Banyaknya Push*/
    printf("Berapa banyak inputan untuk PUSH? [Max 10] : ");
        scanf("%d", &n);
    printf ("Push/ Masukan InfoTop!\n\n");
    for(i=0;i<n;i++)
    {
        if(i==MaxEl) {
            printf("\nSTACK penuh :)\n\n");
            i=n; //berhenti
        }else {
            printf("\tTop[%d] ,--> InfoTop : ", Top(S)+1); scanf("%d",&y);
            Push(&S,y);
        }
    }

    printf ("\nTampilan STACK");
    printf ("\n\tTop   |  InfoTop \n\t----------------\n");
    i=Top(S);
    while (i>=1)
    {
        printf ("\t[%d]   |   [%d] \n", i, (S).T[i]);
        i--;
    }

    printf ("\nCoba Pop-kan! [y/t]");
                pil=getche();
                if (pil=='y' || pil=='Y'){
                    goto atas;
                }else {
                    goto bawah;
                }
    /*Perintah Mengambil STACK*/
        atas:
            printf ("\n\tTop   |  InfoTop \n\t----------------\n");
                Pop (&S, &y);
            i=Top(S);
            while (i>=1)
            {
                printf ("\t[%d]   |   [%d] \n", i, (S).T[i]);
                i--;
            }
            printf ("\nIngin POP lagi ? [y/t]");
                pil=getche();
                if (pil=='y' || pil=='Y'){
                    if ((Top(S) < 1))
                    {
                        printf ("\nStack Kosong :(, tidak bisa Pop.");
                        goto bawah;
                    }else
                    {
                        goto atas;
                    }
                }else {
                    goto bawah;
                }
    bawah:
    /*Mengecek Kembali STACK*/
    printf("\n\nCek STACK kosong ?  : %s\n", IsEmpty(S)?"Ya":"Tidak");
    printf("Cek STACK penuh  ?  : %s\n\n", IsFull(S)?"Ya":"Tidak");
    return 0;
}
