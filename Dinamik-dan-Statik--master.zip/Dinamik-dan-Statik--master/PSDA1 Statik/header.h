#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

#define true 1
#define false 0
#define boolean unsigned char

#define Nil 0 /*stack dengan elemen kosong*/
#define MaxEl 10

typedef int infotype;
typedef int address; /*indeks tabel*/

typedef struct {
    infotype T[MaxEl+1]; /*tabel penyimpan elemen*/
    address TOP; /*alamat TOP : elemen puncak*/
}Stack;

#define Top(S) (S).TOP
#define InfoTop(S) (S).T[(S).TOP]

Stack S;
infotype X;

/*konstruktor*/
void CreateEmpty (Stack *S);

/*Predikat*/
boolean IsEmpty (Stack S);
boolean IsFull (Stack S);

/*Menambahkan elemen ke stack*/
void Push (Stack *S, infotype X);

/*Menghapus elemen stack*/
void Pop (Stack *S, infotype *X);

#endif // STACK_H_INCLUDED
