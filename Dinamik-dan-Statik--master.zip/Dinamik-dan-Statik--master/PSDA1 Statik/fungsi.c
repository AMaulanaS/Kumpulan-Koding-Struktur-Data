#include "header.h"


void CreateEmpty (Stack *S)
{
    Top(*S) = Nil;
    InfoTop (*S) = Nil;
}

boolean IsEmpty (Stack S)
{
    return (Top(S)==Nil);
}

boolean IsFull (Stack S)
{
    return (Top(S)==MaxEl);
}

void Push (Stack *S, infotype x)
{
    Top(*S)++;
    InfoTop(*S)=x;
}

void Pop (Stack *S, infotype *x)
{
    *x=InfoTop(*S);
    Top(*S)--;
}


